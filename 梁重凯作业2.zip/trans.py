import os
import clip
from torch import nn
from torch.utils.data import DataLoader
from torchvision.datasets import CIFAR10
from torch.nn import functional as F
from torchvision.datasets import ImageFolder
from loguru import logger
import torch
import matplotlib.pyplot as plt

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class Net(nn.Module):

    def __init__(self):
        super(Net, self).__init__()
        self.model, self.preprocess = clip.load('ViT-B/32', device)
        self.linear = nn.Linear(512, 131,device=device,dtype=torch.half)

    def forward(self, x):
        features = self.model.encode_image(x)
        features = features.detach()
        return self.linear(features)


net = Net()
optimizer = torch.optim.SGD(net.parameters(), lr=1e-2)

# root = os.path.expanduser("~/.cache")
# train = CIFAR10(root, download=True, train=True, transform=net.preprocess)
# val = CIFAR10(root, download=True, train=True,val =True,transform=net.preprocess)
# test = CIFAR10(root, download=True, train=False,transform=net.preprocess)
# trainload = DataLoader(train, batch_size=8)
# valload = DataLoader(val, batch_size=8)
# testload = DataLoader(test, batch_size=8)


ROOT_TRAIN = r'C:\Users\26134\PycharmProjects\pythonProject\data\train'
ROOT_val = r'C:\Users\26134\PycharmProjects\pythonProject\data\val'
ROOT_TEST = r'D:\download\Fruit-Images-Dataset-master\Fruit-Images-Dataset-master\Test'
train_dataset = ImageFolder(ROOT_TRAIN, transform=net.preprocess)
trainload = DataLoader(train_dataset, batch_size=64, shuffle=True)

val_dataset = ImageFolder(ROOT_val, transform=net.preprocess)
valload = DataLoader(val_dataset, batch_size=64, shuffle=True)

test_dataset = ImageFolder(ROOT_TEST, transform=net.preprocess)
testload = DataLoader(test_dataset, batch_size=64, shuffle=True)


storeParam = {}
for name, param in net.model.visual.named_parameters():
    storeParam[name] = param.detach().clone()
for name, param in net.linear.named_parameters():
    storeParam[name] = param.detach().clone()
loss_train = []
acc_train = []
loss_val = []
acc_val = []
loss_test = []
acc_test = []
for epoch in range(20):
    print("epoch=",epoch+1)
    loss = 0
    current = 0
    n = 0
    for images, labels in trainload:
        images, labels = images.to(device), labels.to(device)
        out = net(images)
        cur_loss = F.cross_entropy(out, labels)
        optimizer.zero_grad()
        cur_loss.backward()
        optimizer.step()
        _, pred = torch.max(out, axis=1)
        cur_acc = torch.sum(labels == pred) / out.shape[0]
        loss += cur_loss.item()
        current += cur_acc.item()
        n = n + 1
    train_loss = loss / n
    train_acc = current / n

    net.eval()
    loss = 0
    current = 0
    n = 0
    with torch.no_grad():
        for images, labels in valload:
            images, labels = images.to(device), labels.to(device)
            out = net(images)
            cur_loss = F.cross_entropy(out, labels)
            _, pred = torch.max(out, axis=1)
            cur_acc = torch.sum(labels == pred) / out.shape[0]
            loss += cur_loss.item()
            current += cur_acc.item()
            n = n + 1
    val_loss = loss / n
    val_acc = current / n
    loss_train.append(train_loss)
    acc_train.append(train_acc)
    loss_val.append(val_loss)
    acc_val.append(val_acc)
plt.plot(loss_train, label='train_loss')
plt.plot(loss_val, label='val_loss')
plt.legend(loc='best')
plt.xlabel('epochs')
plt.ylabel('loss')
plt.title("loss")
plt.show()

plt.plot(acc_train, label='train_acc')
plt.plot(acc_val, label='val_acc')
plt.legend(loc='best')
plt.xlabel('epochs')
plt.ylabel('accuracy')
plt.title("acc")
plt.show()

net.eval()
loss = 0
current = 0
n = 0
with torch.no_grad():
    for images, labels in testload:
        images, labels = images.to(device), labels.to(device)
        out = net(images)
        cur_loss = F.cross_entropy(out, labels)
        _, pred = torch.max(out, axis=1)
        cur_acc = torch.sum(labels == pred) / out.shape[0]
        loss += cur_loss.item()
        current += cur_acc.item()
        n = n + 1
test_loss = loss / n
test_acc = current / n
print('test_loss=' + str(test_loss))
print('test_acc=' + str(test_acc))

