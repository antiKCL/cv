import torch
from torch import nn


class MyNet(nn.Module):

    def __init__(self):
        super(MyNet, self).__init__()
        self.c1 = nn.Conv2d(in_channels=3, out_channels=96, kernel_size=11, stride=4, padding=2)
        self.ReLU = nn.ReLU()
        self.s1 = nn.MaxPool2d(kernel_size=3, stride=2)
        self.c2 = nn.Conv2d(in_channels=96, out_channels=16, kernel_size=5, stride=1, padding=2)
        self.s2 = nn.MaxPool2d(kernel_size=3, stride=2)
        self.flatten = nn.Flatten()
        self.f3 = nn.Linear(400, 131)

    def forward(self, x):
        x = self.ReLU(self.c1(x))
        x = self.s1(x)
        x = self.ReLU(self.c2(x))
        x = self.s2(x)
        x = self.flatten(x)
        x = self.f3(x)
        return x


if __name__ == '__main__':
    r = torch.rand([1, 3, 100, 100])
    model = MyNet()
    y = model(r)
    print(y)