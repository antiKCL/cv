import torch.cuda

from ultralytics import YOLO
# Load a model
model = YOLO('ultralytics/ultralytics/cfg/models/v8/yolov8-ghost.yaml').load('yolov8n.pt')


if __name__=='__main__':
    # Train the model
    torch.cuda.empty_cache()
    model.train(data='datasets/coco.yaml', epochs=50, imgsz=640, save_period=5,device='cuda',freeze = [0,1,2,3,4,5,6,7,8,9,10,11,12])